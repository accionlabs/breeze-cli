def get_fixtures_file_content(folder: str):
    return f"""import {{ test as base }} from 'playwright-bdd';
import * as Pages from '../../fixtures/{folder}/pages';
 
const createTestFunction = (PageClass) => async ({{ page }}, use) => {{
    await use(new PageClass(page));
}};
 
const toCamelCase = (str) =>
    str.charAt(0).toLowerCase() + str.slice(1);
 
const pageClasses = {{}};
 
for (const [name, PageClass] of Object.entries(Pages)) {{
    const camelKey = toCamelCase(name);
    pageClasses[camelKey] = createTestFunction(PageClass);
}}
 
export const test = base.extend(pageClasses);
 
"""


def create_fixture_files(folder):
    # File paths
    fixture_file = folder / "fixture.js"
    pages_file = folder / "pages.js"
    # Create fixture.js if it doesn't exist
    if not fixture_file.exists():
        fixture_file.write_text(get_fixtures_file_content(folder.name))
        print(f"Created file: {fixture_file}")
    else:
        print(f"File already exists: {fixture_file}")
    # Create pages.js if it doesn't exist
    if not pages_file.exists():
        pages_file.write_text("")
        print(f"Created file: {pages_file}")
    else:
        print(f"File already exists: {pages_file}")
