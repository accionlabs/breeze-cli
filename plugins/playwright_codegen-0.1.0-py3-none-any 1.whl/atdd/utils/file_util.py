import os
from pathlib import Path
from docx import Document
import shutil
import textwrap
from atdd.utils.hooks_util import create_hooks_files
from atdd.agents.code_generator import (
    compare_and_generate_updated_content,
    generate_feature_file_content,
    generate_pages_and_step_definition,
)
from atdd.utils.code_utils import remove_markdown_fences
from atdd.utils.fixtures_util import get_fixtures_file_content
from atdd.utils.setup_util import (
    clean_and_standardize_step_imports,
    create_pages_js,
    add_import_for_page_object,
)

def write_file(path: Path, content: str):
    """
    Writes the content to a file at the specified path. Creates directories if they don't exist.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as file:
        file.write(content)
    print(f"✅ File written to: {path}")

def write_file_content(path: Path, content: str) -> None:
    """
    Writes content to the file, but compares with existing file content if file already exists.
    Uses LLM to generate updated content if needed.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)

    if path.exists():
        print(f"File already exists: {path.name}")
        with open(path, "r", encoding="utf-8") as file:
            old_file_content = file.read().strip()

        # Generate updated content based on diff
        updated_content = compare_and_generate_updated_content(old_file_content, content)

        with open(path, "w", encoding="utf-8") as file:
            file.write(updated_content)
        print(f"✅ File updated at: {path}")
    else:
        with open(path, "w", encoding="utf-8") as file:
            file.write(content)
        print(f"✅ New file written to: {path}")

def delete_files(file_path):
    """
    Deletes a file if it exists.
    """
    if os.path.isfile(file_path):
        os.remove(file_path)
        print(f"Deleted file: {file_path}")
    else:
        print(f"File not found: {file_path}")


def deleteFeatureAndStepFiles(deleted_docx_files, target_playwright_project_root):
    for req_file in deleted_docx_files:
        req_file = Path(req_file)
        folder_name = req_file.parent.name
        print(f"The folder name is {folder_name}")

        feature_file_path = (
            target_playwright_project_root / "tests/features" / folder_name / f"{req_file.stem}.feature"
        )
        step_file_path = (
            target_playwright_project_root / "tests/steps" / folder_name / f"{req_file.stem}_step.js"
        )

        delete_files(feature_file_path)
        delete_files(step_file_path)

        feature_dir = feature_file_path.parent
        steps_dir = target_playwright_project_root / "tests/steps" / folder_name
        fixtures_dir = target_playwright_project_root / "tests/fixtures" / folder_name
        hooks_dir = target_playwright_project_root / "tests/hooks" / folder_name

        try:
            if feature_dir.is_dir() and not any(feature_dir.iterdir()):
                shutil.rmtree(feature_dir)
                shutil.rmtree(steps_dir)
                shutil.rmtree(fixtures_dir)
                shutil.rmtree(hooks_dir)

                print(f"✅ Deleted empty directory: {feature_dir}")
            else:
                print(f"⚠️ Not deleted (not empty or missing): {feature_dir}")
        except Exception as e:
            print(f"❌ Failed to delete {feature_dir}: {e}")


def print_file_list(title, file_list, icon):
    """
    Pretty-prints a list of files with a title and optional icon.
    """
    print(f"\n{title}")
    print("-" * len(title))

    if file_list:
        for path in file_list:
            wrapped_path = textwrap.fill(
                str(path), width=100, initial_indent=f"{icon} ", subsequent_indent="    "
            )
            print(wrapped_path)
    else:
        print("  None")

def generate_playwright_code(docx_files, target_playwright_project_root):
    """
    Main driver function: Converts docx-based requirements to:
      - .feature file
      - step definition (.js)
      - page objects
      - fixture file

    All files are written into the Playwright project structure.
    """
    for req_file in docx_files:
        req_file = Path(req_file)
        folder_name = req_file.parent.name
        print(f"The folder name is {folder_name}")

        # Define output paths
        feature_file_path = (
            target_playwright_project_root / "tests/features" / folder_name / f"{req_file.stem}.feature"
        )
        step_file_path = (
            target_playwright_project_root / "tests/steps" / folder_name / f"{req_file.stem}_step.js"
        )
        pom_folder = target_playwright_project_root / "tests/pages" / folder_name
        fixture_file = target_playwright_project_root / "tests/fixtures" / folder_name / "fixture.js"

        # Read content from docx file
        doc = Document(req_file)
        requirements_text = "\n".join(p.text for p in doc.paragraphs)

        print(f"Requirement test is \n {requirements_text}")
        # Generate feature file content
        feature_result = generate_feature_file_content(requirements_text)
        write_file(feature_file_path, remove_markdown_fences(feature_result))

        # Generate step definition and page objects
        with open(feature_file_path) as f:
            feature_text = f.read()

        response = generate_pages_and_step_definition(requirements_text, feature_text)
        MAX_ATTEMPTS = 3
        attempt = 0

        while attempt < MAX_ATTEMPTS and response is None:
            try:
                response = generate_pages_and_step_definition(requirements_text, feature_text)
                print(f"Attempt {attempt + 1}: Eventual Result = {response}")
            except Exception as e:
                print(f"Attempt {attempt + 1} failed due to: {e}")
            attempt += 1

        if response is None:
            raise RuntimeError("❌ Failed to generate response after 3 attempts.")
        print(f"eventual result = {response}")

        # Save step definition
        write_file(step_file_path, response.step_definition.content)
        clean_and_standardize_step_imports(step_file_path)
        print(f"Step definition file {step_file_path} content is:\n{response.step_definition.content}")

        # Save Page Objects
        for po in response.page_objects:
            print(f"\nPage Object File: {po.name}\n")
            print(po.content)

            page_object_file = pom_folder / po.name
            write_file_content(page_object_file, po.content)
            add_import_for_page_object(page_object_file)

        print("\n✅ Page Objects created")

        # Create pages.js and fixture file
        create_pages_js(folder_name, target_playwright_project_root)
        fixture_file.write_text(get_fixtures_file_content(folder_name))
        hooks_folder = Path(target_playwright_project_root).resolve() / f"tests/hooks/{folder_name}"
        hooks_folder.mkdir(parents=True, exist_ok=True)
        create_hooks_files(hooks_folder)


def create_custom_js(PLAYWRIGHT_REPO_CLONE_PATH):
    # Define the path for the 'scripts' folder
    scripts_path = Path(PLAYWRIGHT_REPO_CLONE_PATH) / "scripts"
    scripts_path.mkdir(parents=True, exist_ok=True)

    # Define the full path to the custom.js file
    js_file_path = scripts_path / "custom.js"

    # Check if the file already exists
    if not js_file_path.exists():
        # JavaScript content for custom.js
        js_content = """
import fs from 'fs/promises';
import { readFileSync } from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';

// Enable `.env` config
dotenv.config();

// Needed to simulate __dirname in ES6 modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const { PROJECT_NAME, IMAGE_PATH, REPORT_TITLE } = process.env;

// Paths
const appJsPath = path.resolve(__dirname, 'test', '..', '..', 'allure-report', 'app.js');
const indexPath = path.resolve(__dirname, 'test', '..', '..', 'allure-report', 'index.html');

// Convert image to Base64
function convertImageToBase64(imagePath) {
  try {
    const imageBuffer = readFileSync(imagePath);
    const ext = path.extname(imagePath).substring(1);
    return `data:image/${ext};base64,${imageBuffer.toString('base64')}`;
  } catch (err) {
    console.error('❌ Error converting image to Base64:', err);
    process.exit(1);
  }
}

// Replace Allure span text in app.js
async function replaceAllureInAppJs() {
  try {
    let data = await fs.readFile(appJsPath, 'utf8');
    const updatedContent = data.replace(
      /A\s*l\s*l\s*u\s*r\s*e\s*<\/\s*span\s*>/g,
      `${PROJECT_NAME}</span>`
    );
    await fs.writeFile(appJsPath, updatedContent, 'utf8');
    console.log('✅ app.js updated successfully.');
  } catch (err) {
    console.error('❌ Error updating app.js:', err);
  }
}

// Customize Allure report (index.html)
async function customizeAllureReport(imageBase64) {
  try {
    const data = await fs.readFile(indexPath, 'utf8');

    const customStyle = `
<style>
      .side-nav__brand {
        background: url('${imageBase64}') 0px center / 40px no-repeat;
        height: 50px;
      }
      .side-nav__brand-text {
        font-size: 16px;
      }
</style>`;

    const customScript = `<script>
      setTimeout(() => {
        const brand = document.querySelector('.side-nav__brand-text');
        if (brand) brand.textContent = '${PROJECT_NAME}';
      }, 1000);

      window.addEventListener('DOMContentLoaded', () => {
        if (!window.MutationObserver) {
          console.error('❌ MutationObserver is not supported in this browser.');
          return;
        }

        const observer = new MutationObserver(() => {
          const titleEl = document.querySelector('.widget__title');
          if (titleEl) {
            const textNode = Array.from(titleEl.childNodes).find(
              node => node.nodeType === Node.TEXT_NODE && node.nodeValue.trim().startsWith('Allure Report')
            );
            if (textNode) {
              textNode.nodeValue = '${PROJECT_NAME}';
              observer.disconnect();
            }
          }
        });

        if (document.body) {
          observer.observe(document.body, { childList: true, subtree: true });
        } else {
          console.error('❌ document.body not found.');
        }
      });
</script>`;

    let result = data.replace('</head>', `${customStyle}\n${customScript}</head>`);
    result = result.replace(/<title>.*?<\/title>/, `<title>${REPORT_TITLE}</title>`);
    result = result.replace(
      /<link\s+rel=["']icon["']\s+href=["'][^"']*["']\s*\/?>/i,
      `<link rel="icon" href="${imageBase64}" />`
    );
    result = result.replace(/>Allure</g, `>${PROJECT_NAME}<`);

    await fs.writeFile(indexPath, result, 'utf8');
    console.log('✅ index.html customized successfully.');
  } catch (err) {
    console.error('❌ Error customizing index.html:', err);
  }
}

// Run both functions
(async () => {
  const base64Logo = convertImageToBase64(IMAGE_PATH);
  await replaceAllureInAppJs();
  await customizeAllureReport(base64Logo);
})();
        """
        
        # Create the file and write the content to it
        with open(js_file_path, 'w',  encoding='utf-8') as js_file:
            js_file.write(js_content)
            print(f"✅ Created 'custom.js' at {js_file_path}")
    else:
        print(f"❌ The file 'custom.js' already exists at {js_file_path}")