import subprocess


def run_command(command: str, cwd: str):
    """Run a shell command and print output or errors."""
    print(f"🔧 Running: {command}")
    try:
        result = subprocess.run(command, shell=True, text=True, check=True, capture_output=True,
                                cwd=cwd)
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"❌ Error running command: {e.cmd}")
        print(e.stderr)