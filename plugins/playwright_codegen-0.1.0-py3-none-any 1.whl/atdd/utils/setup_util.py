import os
import shutil
from pathlib import Path

from atdd.utils.commandline_util import run_command
from atdd.utils.fixtures_util import create_fixture_files
from atdd.utils.hooks_util import create_hooks_files


def setup_basic_structure(requirements_path, target_playwright_project_root):
    """
    Sets up the folder structure for the Playwright project based on the requirements.
    Creates necessary directories and calls functions to create fixture and hook files.
    """
    req_root = Path(requirements_path).resolve()
    projects = [f.name for f in req_root.iterdir() if f.is_dir()]
    print(f"Projects are: {projects}")

    for folder_name in projects:
        # Mapping of folder categories and their corresponding paths
        file_categories = {
            "features": f"tests/features/{folder_name}",
            "steps": f"tests/steps/{folder_name}",
            "pages": f"tests/pages/{folder_name}",
            "fixtures": f"tests/fixtures/{folder_name}",
            "hooks": f"tests/hooks/{folder_name}",
        }

        for category, path in file_categories.items():
            folder = Path(target_playwright_project_root).resolve() / path
            folder.mkdir(parents=True, exist_ok=True)
            print(f"Ensured {category} folder exists: {folder}")
            print(f"category is {category} *************************")
            if category == "fixtures":
                print("creating fixture ****************************")
                create_fixture_files(folder)
            if category == "hooks":
                print("creating hooks ****************************")
                create_hooks_files(folder)


def clean_playwright_project(project_dir: str):
    """
    Cleans the Playwright project directory by deleting unnecessary files and folders.
    """
    project_path = Path(project_dir).resolve()

    # 1. Delete the 'playwright-config.ts' file
    playwright_config_file = project_path / "playwright.config.ts"
    if playwright_config_file.exists():
        playwright_config_file.unlink()
        print("Playwright config file deleted.")

    # 2. Delete the 'tests-examples' folder if it exists
    examples_path = project_path / "tests-examples"
    if examples_path.exists() and examples_path.is_dir():
        shutil.rmtree(examples_path)
        print(f"🗑️ Deleted folder: {examples_path}")
    else:
        print(f"✅ Folder not found or already removed: {examples_path}")

    # 3. Delete all files in the 'tests' folder
    tests_path = project_path / "tests"
    if tests_path.exists() and tests_path.is_dir():
        for file in tests_path.iterdir():
            file.unlink()
            print(f"🗑️ Deleted file: {file}")
    else:
        print(f"⚠️ 'tests' directory not found at: {tests_path}")


def initiate_project_setup(tests_dir) -> bool:
    """
    Initializes the Playwright project by running necessary setup commands and cleaning up unnecessary files.
    """
    project_already_configured = (Path(tests_dir) / "playwright.config.js").exists()
    if not project_already_configured:
        # List of setup commands to run
        commands = [
            "npm init playwright@latest -- --lang=js --quiet --install-deps",
            "npm install -D playwright-bdd@latest",
            "npm i -D allure-playwright dotenv"
        ]

        # Run each setup command
        for cmd in commands:
            run_command(cmd, tests_dir)

        clean_playwright_project(tests_dir)
        return True
    else:
        return False


def clean_and_standardize_step_imports(step_file_path: Path):
    """
    Cleans and standardizes the imports in a step definition file by removing old imports
    and adding standard ones.
    """
    print("Processing this file: " + str(step_file_path))

    # Check if the file exists
    if not step_file_path.exists():
        print(f"Error: {step_file_path} does not exist!")
        return

    fixture_import = f"import {{ test }} from '../../fixtures/{step_file_path.parent.name}/fixture';"

    # Standard imports to be added
    standard_imports = [
        "import { createBdd } from 'playwright-bdd';",
        fixture_import,
        "import { expect } from '@playwright/test';"
    ]

    # Read the existing file content
    with open(step_file_path, "r") as f:
        lines = f.readlines()

    # Remove all lines that start with "import"
    content_wo_imports = [line for line in lines if not line.strip().startswith("import ")]

    # Join standard imports and keep the rest of the file
    final_content = "\n".join(standard_imports) + "\n\n" + "".join(content_wo_imports)

    # Write the updated content back to the file
    with open(step_file_path, "w") as f:
        f.write(final_content)

    print(f"✅ Cleaned & updated imports in: {step_file_path}")


def create_pages_js(folder_name, target_playwright_project_root):
    """
    Creates a new 'pages.js' file that exports all page objects from the pages folder for the given project.
    """
    pages_js_path = target_playwright_project_root / "tests" / "fixtures" / folder_name / "pages.js"
    pages_folder = target_playwright_project_root / "tests" / "pages" / folder_name
    pages_js_path.parent.mkdir(parents=True, exist_ok=True)

    if not pages_folder.exists():
        print(f"Error: {pages_folder} does not exist!")
        return

    # New export statements
    new_exports = {
        f"export * from '../../pages/{folder_name}/{page_file.stem}';"
        for page_file in pages_folder.glob("*.js")
    }

    # If the pages.js file exists, remove it
    if pages_js_path.exists():
        os.remove(pages_js_path)
        print(f"Removed old pages.js file: {pages_js_path}")

    # Write the new export statements to a new pages.js file
    with open(pages_js_path, "w") as f:
        f.write("\n".join(new_exports) + "\n")

    print(f"Created new pages.js at: {pages_js_path}")


def is_expect_imported(js_file_path: str | Path) -> bool:
    """
    Checks if the 'expect' import from '@playwright/test' is already present in the provided JavaScript file.
    """
    js_path = Path(js_file_path)
    if not js_path.exists():
        print(f"❌ File not found: {js_path}")
        return False

    import_acc = ""
    for raw in js_path.read_text().splitlines():
        line = raw.strip()
        if line.lower().startswith("import"):
            import_acc += " " + line.replace(" ", "")
            # Quick single‑line check
            if "expect" in import_acc and "@playwright/test" in import_acc:
                return True
            # Continue accumulating because it may be multiline
        elif import_acc:  # We just finished an import block
            if "expect" in import_acc and "@playwright/test" in import_acc:
                return True
            import_acc = ""  # Reset for next import

    return False


def add_import_for_page_object(page_obj_file: Path) -> None:
    """
    Prepends `import { expect } from '@playwright/test';` to the file
    if it is not already imported.
    """
    if is_expect_imported(page_obj_file):
        print(f"⏩ expect-import already present in {page_obj_file}")
        return

    # Prepend the import
    original = page_obj_file.read_text()
    page_obj_file.write_text("import { expect } from '@playwright/test';\n\n" + original)
    print(f"✅ Added expect-import to {page_obj_file}")
