import re


def remove_markdown_fences(text: str) -> str:
    return re.sub(r"```(?:\w+)?\n(.*?)```", r"\1", text, flags=re.DOTALL)