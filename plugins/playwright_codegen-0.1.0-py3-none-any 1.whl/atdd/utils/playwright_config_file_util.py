from pathlib import Path


def create_playwright_configuration_file(requirements_path,
                                         target_playwright_project_root):
    # 1. Set up the initial imports.
    content = """import { defineConfig, devices } from '@playwright/test';
import { defineBddConfig } from 'playwright-bdd';

"""
    # 2. Add necessary testDir constants
    requirements_dir = Path(requirements_path)
    playwright_dir = Path(target_playwright_project_root)
    for subfolder in requirements_dir.iterdir():
        if subfolder.is_dir():
            name = subfolder.name
            test_dir_value = f"""const {name}TestDir = defineBddConfig({{
  features: 'tests/features/{name}/***.feature',
  steps: ['tests/steps/{name}/***steps.js',
          'tests/fixtures/{name}/fixture.js',
          'tests/hooks/hooks.js'
         ],
  outputDir: ".features-{name}"
  }});
"""
            content += test_dir_value
            content += "\n"

    # 3. Add exports content
    export_content = """export default defineConfig({
  testDir:'./tests',
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 1 : undefined,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [['html'],
  ['list'],
  ['allure-playwright', { outputFolder: 'allure-results' }]
  ],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('/')`. */
    // baseURL: 'http://127.0.0.1:3000',
 
    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'on-first-retry'
  },
 
  /* Configure projects for major browsers */
  projects: [
  
"""
    content += export_content

    # Add projects dynamically
    for subfolder in requirements_dir.iterdir():
        if subfolder.is_dir():
            name = subfolder.name
            project_array = f"""    {{ name: '{name}',
        use: {{ ...devices['Desktop Chrome']}},
        testDir: {name}TestDir
    }},"""
            content += project_array
            content += "\n"

    content += f"""  ],
}});
"""

    config_file = Path(playwright_dir).resolve() / "playwright.config.js"
    config_file.write_text(content)