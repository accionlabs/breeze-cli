def create_hooks_files(hooks_folder):
    hooks_file = hooks_folder / "hooks.js"
    # Create hooks.js if it doesn't exist
    if not hooks_file.exists():
        hooks_file.write_text(get_hooks_content())
        print(f"Created file: {hooks_file}")
    else:
        print(f"File already exists: {hooks_file}")


def get_hooks_content():
    return """import { chromium, firefox } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
 
const { Before, After, BeforeAll, AfterAll, } = createBdd();
 
Before(async ({ page }) => {
    console.log("This is before.");
});
 
After(async () => {
    console.log("This is a After.")
});
 
BeforeAll(async ({ browser }) => {
    // const page = firefox.launch();
    console.log("This is Before all.");
});
 
AfterAll(async () => {
    console.log("This is a AfterAll.")
});

  """
