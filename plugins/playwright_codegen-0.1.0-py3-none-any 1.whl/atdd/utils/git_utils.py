import os
import subprocess
from dotenv import load_dotenv
from datetime import datetime
import tempfile
from pathlib import Path
import shutil
import stat

# Load environment variables from .env file
load_dotenv()

# Fetch required variables from environment
TESTCASES_GIT_PLATFORM = os.getenv("TESTCASES_GIT_PLATFORM", "github").lower()
TESTCASES_REPO_NAME = os.getenv("TESTCASES_REPO_NAME")
TESTCASES_REPO_OWNER = os.getenv("TESTCASES_REPO_OWNER")
TESTCASES_REPO_GIT_TOKEN = os.getenv("TESTCASES_REPO_GIT_TOKEN")

PLAYWRIGHT_REPO_NAME = os.getenv("PLAYWRIGHT_REPO_NAME")
PLAYWRIGHT_REPO_OWNER = os.getenv("PLAYWRIGHT_REPO_OWNER")
PLAYWRIGHT_GIT_PLATFORM = os.getenv("PLAYWRIGHT_GIT_PLATFORM", "github").lower()
PLAYWRIGHT_REPO_GIT_TOKEN = os.getenv("PLAYWRIGHT_REPO_GIT_TOKEN")
PLAYWRIGHT_REPO_BRANCH_NAME = os.getenv("PLAYWRIGHT_REPO_BRANCH_NAME", "main").lower()
PLAYWRIGHT_OUTPUT_DIR=os.getenv("PLAYWRIGHT_OUTPUT_DIR")
PLAYWRIGHT_BRANCH_TO_PUSH = os.getenv("PLAYWRIGHT_BRANCH_TO_PUSH")

# Set Git platform domains for various platforms
TESTCASES_GIT_DOMAIN = {
    "gitlab": "gitlab.com",
    "github": "github.com"
}.get(TESTCASES_GIT_PLATFORM) or (_ for _ in ()).throw(ValueError("Unsupported code Repository"))

PLAYWRIGHT_GIT_DOMAIN = {
    "gitlab": "gitlab.com",
    "github": "github.com"
}.get(PLAYWRIGHT_GIT_PLATFORM) or (_ for _ in ()).throw(ValueError("Unsupported code Repository"))

# Construct repository URLs using the OAuth token
requirements_repo_url = (
    f"https://oauth2:{TESTCASES_REPO_GIT_TOKEN}@"
    f"{TESTCASES_GIT_DOMAIN}/{TESTCASES_REPO_OWNER}/"
    f"{TESTCASES_REPO_NAME}.git"
)

playwright_repo_url = (
    f"https://oauth2:{PLAYWRIGHT_REPO_GIT_TOKEN}@"
    f"{PLAYWRIGHT_GIT_DOMAIN}/{PLAYWRIGHT_REPO_OWNER}/"
    f"{PLAYWRIGHT_REPO_NAME}.git"
)


# Generate a timestamp for project folder names
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

# Define temporary clone paths for both repositories
TESTCASES_REPO_CLONE_PATH = os.path.join(tempfile.gettempdir(), TESTCASES_REPO_NAME)
PLAYWRIGHT_REPO_CLONE_PATH = os.path.join(PLAYWRIGHT_OUTPUT_DIR, PLAYWRIGHT_REPO_NAME)

# Create the directories if they do not exist
os.makedirs(TESTCASES_REPO_CLONE_PATH, exist_ok=True)
os.makedirs(PLAYWRIGHT_REPO_CLONE_PATH, exist_ok=True)

def force_delete_folder(path):
    def onex(func, path, exc_info):
        # Called when deletion fails; tries to force permissions and retry
        try:
            os.chmod(path, stat.S_IWRITE)
            func(path)
        except Exception as e:
            print(f"⚠️ Could not forcibly delete: {path} -> {e}")

    shutil.rmtree(path,onexc=onex)
    print(f"✅ Deleted: {path}")

def track_requirement_docx():
    """
    This function clones the repositories, checks for any file changes in the requirements repo, 
    and returns the added, modified, or deleted .docx files based on git diff.
    """
    
    docx_files = []  # List to store paths of .docx files
    deleted_docx_files = []  # List to store paths of deleted .docx files

    # Define paths for the repositories
    requirements_repo = os.path.join(TESTCASES_REPO_CLONE_PATH, TESTCASES_REPO_NAME)
    playwright_repo = os.path.join(PLAYWRIGHT_REPO_CLONE_PATH)
    requirements_repo_old = os.path.join(TESTCASES_REPO_CLONE_PATH, TESTCASES_REPO_NAME + "_OLD")

    # Clean up old temp clone directories if they exist
    for path in [requirements_repo, playwright_repo, requirements_repo_old]:
        if os.path.exists(path):
            # subprocess.run(["rm", "-rf", path], check=True)
            force_delete_folder(path)

    # Clone the latest requirements repo
    subprocess.run(["git", "clone", requirements_repo_url, requirements_repo], check=True)
    print(f"Requirements repo cloned at: {requirements_repo}")  

    # Clone the Playwright repo
    subprocess.run(["git", "clone", "--branch", PLAYWRIGHT_REPO_BRANCH_NAME, playwright_repo_url, playwright_repo], check=True)
    print(f"Playwright repo cloned at: {playwright_repo}")  

    commit_info_path = os.path.join(playwright_repo, "version.txt")

    # First time setup if commit info file doesn't exist
    if not os.path.exists(commit_info_path):
        print("📁 No commitInfo.txt found. First time setup.")

        requirements_path = os.path.join(requirements_repo, "testcases")
        req_root = Path(requirements_path).resolve()
        docx_files = list(req_root.glob("*.docx")) + list(req_root.glob("*/*.docx"))
        print(f"Requirements root: {req_root}")
        print(f"Found .docx files: {docx_files}")

        # Save the latest commit hash and timestamp for future reference
        latest_commit = subprocess.check_output(["git", "-C", requirements_repo, "log", "-1", "--format=%H"]).decode().strip()
        timestamp = subprocess.check_output(["git", "-C", requirements_repo, "log", "-1", "--format=%ct"]).decode().strip()
        with open(commit_info_path, "w") as f:
            f.write(f"commit_hash={latest_commit}\n")
            f.write(f"timestamp={timestamp}\n")
        print("✅ Initial commit info saved.")
    
    else:
        # If commit info exists, perform a diff between old and new commits
        with open(commit_info_path, "r") as f:
            lines = f.readlines()
        
        old_commit = next((line.split("=")[1].strip() for line in lines if "commit_hash" in line), None)
        if not old_commit:
            raise Exception("❌ 'commit_hash' not found in commitInfo.txt")

        # Clone requirements repo again for the old commit snapshot
        subprocess.run(["git", "clone", requirements_repo_url, requirements_repo_old], check=True)
        subprocess.run(["git", "-C", requirements_repo_old, "checkout", old_commit], check=True)

        # Get the diff between old and new commit for file changes
        diff_output = subprocess.check_output([
            "git", "-C", requirements_repo, "diff", "--name-status", f"{old_commit}..HEAD"
        ]).decode().strip().splitlines()

        # If no changes, return the current docx files
        if not diff_output:
            print("✅ No file changes detected.")
            return docx_files, deleted_docx_files

        print("📦 Detected file changes:")
        
        # Analyze the diff output and identify added, modified, or deleted files
        docx_files = []
        for line in diff_output:
            parts = line.split(maxsplit=1)
            if len(parts) != 2:
                continue  # skip invalid lines
            status, path = parts
            if not path.endswith(".docx"):
                continue  # Only care about .docx files

            # Add or modify .docx files
            if status in ["A", "M"]:
                abs_path = os.path.join(requirements_repo, path)
                docx_files.append(abs_path)
                print(f"  ➕ {status} {path} - Added/Modified file at: {abs_path}")
            # Handle deleted .docx files
            elif status == "D":
                abs_path = os.path.join(requirements_repo_old, path)
                deleted_docx_files.append(abs_path)
                print(f"  ❌ {status} {path} - Deleted file at: {abs_path}")

        # Update the commit info with the new commit hash and timestamp
        new_commit = subprocess.check_output(["git", "-C", requirements_repo, "log", "-1", "--format=%H"]).decode().strip()
        new_timestamp = subprocess.check_output(["git", "-C", requirements_repo, "log", "-1", "--format=%ct"]).decode().strip()
        with open(commit_info_path, "w") as f:
            f.write(f"commit_hash={new_commit}\n")
            f.write(f"timestamp={new_timestamp}\n")

        print("✅ commitInfo.txt updated with new commit.")
    
    return docx_files, deleted_docx_files  # Always return docx files regardless of changes

def handle_remove_readonly(func, path, exc_info):
    """Handle read-only files by changing permissions and retrying."""
    os.chmod(path, stat.S_IWRITE)  # Change permission to write
    func(path)



def push_playwright_repo():

    def run(cmd, capture_output=False):
        return subprocess.run(
            cmd,
            cwd=PLAYWRIGHT_REPO_CLONE_PATH,
            check=True,
            text=True,
            stdout=subprocess.PIPE if capture_output else None
        )

    run(["git", "fetch", "origin"])

    # Delete remote branch if exists and not 'main'
    branches = run(["git", "branch", "-r"], capture_output=True).stdout
    if f"origin/{PLAYWRIGHT_BRANCH_TO_PUSH}" in branches and PLAYWRIGHT_BRANCH_TO_PUSH != "main":
        print(f"{PLAYWRIGHT_BRANCH_TO_PUSH} branch already exists deleting it.")
        run(["git", "push", "origin", "--delete", PLAYWRIGHT_BRANCH_TO_PUSH])

    run(["git", "checkout", "-B", PLAYWRIGHT_BRANCH_TO_PUSH])
    run(["git", "add", "."])

    status = run(["git", "status", "--porcelain"], capture_output=True).stdout.strip()
    if status:
        run(["git", "commit", "-m", f"Update {PLAYWRIGHT_BRANCH_TO_PUSH}"])

    run(["git", "push", "-u", "origin", PLAYWRIGHT_BRANCH_TO_PUSH, "--force"])
    print(f"✅ Pushed to branch '{PLAYWRIGHT_BRANCH_TO_PUSH}' from {PLAYWRIGHT_REPO_CLONE_PATH}")
