from pydantic import BaseModel
from typing import List


class PageObjectFile(BaseModel):
    name: str        # e.g., loginPage.js
    content: str     # the full class code


class StepDefinitionFile(BaseModel):
    content: str     # the full step definitions code


class AutomationFiles(BaseModel):
    step_definition: StepDefinitionFile
    page_objects: List[PageObjectFile]


class FeatureClass(BaseModel):
    feature_content: str




