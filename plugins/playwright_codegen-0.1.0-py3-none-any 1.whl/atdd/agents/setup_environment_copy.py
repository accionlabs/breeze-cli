import os
from pathlib import Path

from langchain import hub
from langchain.agents import AgentExecutor
from langchain.agents.structured_chat.base import create_structured_chat_agent
from langchain.tools import StructuredTool
from langchain_core.output_parsers import StrOutputParser

from atdd.utils.llm import get_llm
from atdd.utils.playwright_config_file_util import create_playwright_configuration_file
from atdd.utils.setup_util import initiate_project_setup, setup_basic_structure

llm = get_llm()
output_parser = StrOutputParser()


def setup_environment_for_tdd() -> str:
    """
        This tool is used to create a blank Playwright javascript environment/project in the location
        (local path or destination folder) passed in as input.

        @:folder the path of the directory where the blank Playwright Javascript project needs to be created.
    """
    requirements_path = os.getenv("TESTCASES_PATH")
    target_playwright_project_root = os.getenv("TARGET_FOLDER")

    if not requirements_path:
        print("❌ REQUIREMENTS_PATH environment variable is not set. Terminating")
        exit(-1)
    if not target_playwright_project_root:
        print("❌ TARGET_FEATURE_FOLDER environment variable is not set. Terminating.")
        exit(-1)

    tests_dir = Path(target_playwright_project_root)
    tests_dir.mkdir(parents=True, exist_ok=True)

    set_up_not_done_earlier = initiate_project_setup(tests_dir)
    if set_up_not_done_earlier:
        setup_basic_structure(requirements_path, target_playwright_project_root)
        create_playwright_configuration_file(requirements_path, target_playwright_project_root)
        return "Project setup successfully."
    return "Project setup successfully."


setup_playwright_project_tool = StructuredTool.from_function(
    func=setup_environment_for_tdd,
    name="setup_playwright_project_tool",
    description="""This tool is used to create a blank Playwright javascript environment/project in the location
    (local path or destination folder) passed in as input."""
)


def setup_project_environment():
    tools = [setup_playwright_project_tool]

    agent = create_structured_chat_agent(
        llm=llm,
        tools=tools,
        prompt=hub.pull("hwchase17/structured-chat-agent"),
    )

    return AgentExecutor.from_agent_and_tools(agent=agent, tools=tools, verbose=True, handle_parsing_errors=True)
