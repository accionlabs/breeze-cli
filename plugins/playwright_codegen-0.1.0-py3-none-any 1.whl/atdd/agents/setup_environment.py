import os
from pathlib import Path
from atdd.utils.file_util import create_custom_js, delete_files
# Import project utilities
from atdd.utils.git_utils import (
    TESTCASES_REPO_CLONE_PATH,
    PLAYWRIGHT_REPO_CLONE_PATH,
    TESTCASES_REPO_NAME
)
from atdd.utils.playwright_config_file_util import create_playwright_configuration_file
from atdd.utils.setup_util import initiate_project_setup, setup_basic_structure


def setup_environment_for_atdd():
    """
    Sets up the Playwright JavaScript automation environment for ATDD (Acceptance Test-Driven Development).
    
    If the target project folder doesn't exist, it creates:
    - Required directory structure
    - Base configuration files
    - Playwright config setup
    """

    # Construct paths to requirement source and target Playwright repo
    requirements_repo = os.path.join(TESTCASES_REPO_CLONE_PATH, TESTCASES_REPO_NAME)
    requirements_path = os.path.join(requirements_repo, "testcases")
    target_playwright_project_root = PLAYWRIGHT_REPO_CLONE_PATH  # Already a path

    print(f"🎯 Target Playwright project path: {target_playwright_project_root}")

    # Safety checks for critical environment paths
    if not requirements_path:
        print("❌ REQUIREMENTS_PATH environment variable is not set. Terminating.")
        exit(-1)
    if not target_playwright_project_root:
        print("❌ TARGET_FEATURE_FOLDER environment variable is not set. Terminating.")
        exit(-1)

    # Ensure the target directory exists
    tests_dir = Path(target_playwright_project_root)
    tests_dir.mkdir(parents=True, exist_ok=True)

    # Check if initial setup was already done
    set_up_not_done_earlier = initiate_project_setup(tests_dir)
    create_custom_js(PLAYWRIGHT_REPO_CLONE_PATH)
    if set_up_not_done_earlier:
        # Create folder structure and config files only if setup is fresh
        setup_basic_structure(requirements_path, target_playwright_project_root)

    # config_file = Path(target_playwright_project_root).resolve() / "playwright.config.js"
    # delete_files(config_file)
    create_playwright_configuration_file(requirements_path, target_playwright_project_root)
