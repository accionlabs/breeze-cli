from dotenv import load_dotenv
from langchain import hub
from langchain.agents import AgentExecutor
from langchain.agents.structured_chat.base import create_structured_chat_agent
from langchain.tools import StructuredTool
from langchain_core.output_parsers import StrOutputParser, PydanticOutputParser
from langchain_core.prompts import PromptTemplate

from atdd.pydantic_classes.playwright_artifact_classes import FeatureClass, AutomationFiles
from atdd.utils.llm import get_llm

load_dotenv()

llm = get_llm()
output_parser = StrOutputParser()


FEATURE_TEMPLATE = PromptTemplate.from_template("""
You are an expert in writing playwright-bdd feature files.

Convert the following requirement text into a valid `.feature` file:
- Follow proper Gherkin Syntax
- Include a proper Feature name.
- Add Background.
- Add user context (persona).
- Use Scenario Outline with Examples where applicable.
- Scenario outline examples should be in proper tabular format per Gherkin.
- Ignore locators.

Requirement:
{requirement_text}

Return a JSON object with this structure:
{{
  "feature_content": "<insert Gherkin formatted .feature content here>"
}}
""")


PAGE_OBJECTS_AND_STEP_FILE_TEMPLATE = PromptTemplate.from_template("""
You are a QA Automation expert using Playwright with the BDD approach in JavaScript.
Your job is to convert a requirement into:-
1. Page Object Model JS files, one per page, each with locators and functions.
2. A step definition file in JavaScript that maps the steps from the `.feature` file passed in. This contains the DSL.

Generate Page Object files. Each file should adhere to the following:-
For each distinct page:
- The Locators should be written according to the Locators provided in the Requirements file.
- Generate a separate Page Object file using Playwright JavaScript
- Use a class-based structure
- Include locators and reusable functions for actions on the page
- the class name should have export before it for example 
  export class EcomLoginPage {{
- Use ES6 syntax strictly.
- Use camelCase naming for function names and camelCase for file names, ending with `Obj.js`.


Generate Step Definition file as follows:-
- All the Page Object Files should have its imports.
- Each Gherkin step (`Given`, `When`, `Then`) must be implemented using `Given`, `When`, and `Then` functions 
  imported from `import {{createBdd}} from 'playwright-bdd';`. 
- Retrieve the Given, When, Then using `const {{ Given, When, Then, And }} = createBdd(test);`
- Use `async/await`, and follow Playwright's best practices with page object usage.
- Use strictly ES6 syntax.
- Use `expect` assertions where applicable.
- Use clear regex matchers for each step.
- Assume appropriate page object class and method names for each action.


The eventual output should be in the JSON format following the Pydantic Object.

Your output should be in this JSON format:
Return a JSON object in the following structure:
{{
  "step_definition": {{
    "content": "<Playwright JavaScript step definitions here>"
  }},
  "page_objects": [
    {{
      "name": "filename1.js",
      "content": "<content of the Page Object class 1>"
    }},
    {{
      "name": "filename2.js",
      "content": "<content of the Page Object class 2>"
    }}
  ]
}}

Here is the Requirement file :
------------------
{requirement_file_content}
------------------

Here is the feature file

------------------
{feature_file_content}
------------------

Finally and must follow instructions:-
Provide code only. No descriptions or explanations before or after the code. 
No explanations or natural language before or after the code.
Ensure the output is in the Pydantic format mentioned.
No code markings like ```json, ```gherkin etc. Never.

Again, PROVIDE CODE ONLY. No descriptions or explanations before or after the code.

Respond with only the raw JSON content that matches the required structure.
Do not include explanations, summaries, markdown code blocks, or comments.

""")


def generate_pages_and_step_definition(requirement_file_content: str, feature_file_content: str) -> dict:
    """
    Uses the given requirement text and feature file and generates Page Object classes and Step Definition file.

    :param feature_file_content: the feature(Gherkins) file text used to generate Page Objects and Step definition file.
    :param requirement_file_content: the requirement text passed in to generate Page Objects and Step definition file.

    :return: the json with Page Objects and Step Definition details.

    """
    print(f"requirements text inside generate_pages_and_step_definition \n {requirement_file_content}.\n")
    print(f"feature text inside generate_pages_and_step_definition \n {feature_file_content}.\n")

    parser = PydanticOutputParser(pydantic_object=AutomationFiles)
    return PAGE_OBJECTS_AND_STEP_FILE_TEMPLATE | llm | parser


def generate_feature_file_content(requirement_text: str) -> str:
    """
    Converts the given requirement text into a .feature file following the playwright-bdd format.
    The generated feature content is saved as a file in the appropriate destination.

    :param requirement_text: the requirement text passed in to generate feature file.
    :return: the content of the feature file created.

    """
    print(f"Requirement text passed in is:- {requirement_text}.")
    parser = PydanticOutputParser(pydantic_object=FeatureClass)
    chain = FEATURE_TEMPLATE | llm | parser

    response = chain.invoke({"requirement_text": requirement_text})
    return response.feature_content


generate_feature_file_tool = StructuredTool.from_function(
    func=generate_feature_file_content,
    name="generate_feature_file_content",
    description="This creates the feature file from the given requirement text. Use this when a txt content is provided"
                "and a feature file is to be generated as output.",
)

generate_pages_and_step_file_tool = StructuredTool.from_function(
    func=generate_pages_and_step_definition,
    name="generate_pages_and_step_definition",
    description="This creates the page objects and the step definition files based on the requirement file"
                "and the feature file content passed in.",
)


def generate_playwright_artifacts() -> AgentExecutor:
    tools = [generate_feature_file_tool, generate_pages_and_step_file_tool]

    agent = create_structured_chat_agent(
        llm=llm,
        tools=tools,
        prompt=hub.pull("hwchase17/structured-chat-agent"),
    )

    return AgentExecutor.from_agent_and_tools(agent=agent, tools=tools, verbose=True,
                                              handle_parsing_errors=True)


