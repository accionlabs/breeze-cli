import json
import re

from dotenv import load_dotenv
from langchain_core.output_parsers import StrOutputParser, PydanticOutputParser
from langchain_core.prompts import PromptTemplate

from atdd.pydantic_classes.playwright_artifact_classes import FeatureClass, AutomationFiles
from atdd.utils.code_utils import remove_markdown_fences
from atdd.utils.llm import get_llm

load_dotenv()

llm = get_llm()
output_parser = StrOutputParser()

FEATURE_TEMPLATE = PromptTemplate.from_template("""
You are an expert in writing playwright-bdd feature files.

Convert the following requirement text into a valid `.feature` file:
- Follow proper Gherkin Syntax
- Include a proper Feature name.
- Add Background.
- Add user context (persona).
- Use Scenario Outline with Examples where applicable.
- Scenario outline examples should be in proper tabular format per Gherkin.
- Ignore locators.
- Every Signle step definitions must be unique.
- user clicks on the 'shop by category' button and user clicks on the "Add to Cart" button are considered same try to keep it unique like
  user clicks on the 'shop by category' button shopbycategory. and user clicks on the "Add to Cart" button AddtoCart                                                                                                                                         

Requirement:
{requirement_text}

Return a JSON object with this structure:
{{
  "feature_content": "<insert Gherkin formatted .feature content here>"
}}

Important:- Respond with only the raw JSON content that matches the required structure.
Do not include explanations, summaries, markdown code blocks, or comments.
""")

PAGE_OBJECTS_AND_STEP_FILE_TEMPLATE = PromptTemplate.from_template("""
You are a QA Automation expert using Playwright with the BDD approach in JavaScript.
Your job is to convert a requirement into:-
1. Page Object Model Javascript files, one per page, each with locators and functions.
2. A step definition file in JavaScript that maps the steps from the `.feature` file passed in. This contains the DSL.

Generate Page files (Generate Javascript code only). Each file should be written in javascript only 100 percente javascript adhering the following rules.
For each distinct page:
- Create Page Object classes with only those names that are provided in the of the Requirements file with the side 
  heading "PageName:-"
- The Locators should be written according to the Locators provided in the Requirements file.
- Generate a separate Page Object file using Playwright JavaScript.
- Use a class-based structure.
- Include locators and reusable functions for actions on the page.
- the class name should have export before it for example 
  export class EcomLoginPage {{
- Use ES6 syntax strictly.
- Use camelCase naming for function names and camelCase for file names, ending with `Obj.js`.
- Extract the names of all the Page Object files from the json that is provided in the requirement file content. Use
  these files only.
- The table will also contain the locators corresponding to the each of the Page object file.

Generate Javascript code only
Generate Step Definition file as follows:-
- Use only those Page Object Classes provided in the requirement file.
- All the Page Object Files should have its imports.
- Each Gherkin step (`Given`, `When`, `Then`) must be implemented using `Given`, `When`, and `Then` functions 
  imported from `import {{createBdd}} from 'playwright-bdd';`. 
- Retrieve the Given, When, Then using `const {{ Given, When, Then }} = createBdd(test);`
- Use `async/await`, and follow Playwright's best practices with page object usage.
- Use strictly ES6 syntax.
- Never use Typescript. Always use javascript syntax only.
- Use `expect` assertions where applicable.
- Use clear regex matchers for each step.
- Assume appropriate page object class and method names for each action.

The following is an example for a function in the Step function. The variable inside the async block should use 
camelCase.Consider the following example:-

Given('I click on My account', async ({{ ecomLoginPage }}) => {{
  await ecomLoginPage.clickOnMyAccount();
}});

Don't use {{page}} in the async block anywhere. Use the Page Object class name instead.
The following is wrong. Don't use this.
Given('I click on My account', async ({{ page }}) => {{

The following are examples of right and wrong method signatures:-
- Given('I click on Register button', async ({{ registrationPage }}) => {{
This is right.

-Given('Navigate to Registration url', async ({{ registrationPage }}, url) => {{
This is right.

- Given('I click on Register button', async ({{ page }}) => {{
This is wrong as the page is being used.

-Given('Navigate to Registration url', async ({{ page }}, url) => {{
This is wrong as page is being used.

-Given('Navigate to Registration url', async ({{ RegistrationPage }}, url) => {{
This is wrong as the variable RegistrationPage starts with a capital. It should be camel case.

The eventual output should be in the JSON format following the Pydantic Object.

Your output should be in this JSON format:
Return a JSON object in the following structure:
{{
  "step_definition": {{
    "content": "<Playwright JavaScript step definitions here>"
  }},
  "page_objects": [
    {{
      "name": "filename1.js",
      "content": "<content of the Page Object class 1>"
    }},
    {{
      "name": "filename2.js",
      "content": "<content of the Page Object class 2>"
    }}
  ]
}}

Here is the Requirement file :
------------------
{requirement_file_content}
------------------

Here is the feature file

------------------
{feature_file_content}
------------------

Finally, must follow instructions:-
Generate Strictly Javascript code only
Provide code only. No descriptions or explanations before or after the code. 
No explanations or natural language before or after the code.
Ensure the output is in the Pydantic format mentioned.
No code markings like ```json, ```gherkin etc. Never.

Again, PROVIDE CODE ONLY. No descriptions or explanations before or after the code.

Respond with only the raw JSON content that matches the required structure.
Do not include explanations, summaries, markdown code blocks, or comments.

Generate Javascript code only.

""")

PAGE_OBJECT_COMPARE_AND_MERGE_PROMPT = PromptTemplate.from_template("""
You are an expert Playwright javascript QA Automation Engineer.
You will be provided with two versions of the Page Object Model classes which are accessed by the Step Function viz old
and new.
Your job is to compare them and generate an updated version. You need to apply the following rules:

Method Comparison:
1. Make sure that all the locators in both the versions are merged and consolidated together.
2. Make sure all the methods in both the versions are merged and consolidated together.
3. Ensure that unused locators are removed.
4. If the method exists in both the old and new file with the same arguments and content, do nothing.
5. If the method is new in the new file (not found in the old file), add it.
6. If the method in the new file is overloaded (i.e., it has the same name but different arguments),
   modify the old method to include the changes (e.g., adding parameters, modifying the method body).
7. Locator Comparison:
     If a new locator is added to the constructor in the new file, add it.
     If a locator already exists, do not add it again. Ensure there’s no redundancy.
8. Never use Typescript. Stick to Javascript.
9. Follow ES6 or higher standards. Never use module.exports or require.
10. Add all the locators in the constructor.                                                                   

General Rules:
The newly generated file should only include the changes (new methods, new locators, and modifications).
Do not add any unnecessary explanations, comments, or extra quotes.
Avoid modifying anything that is already correct in the original file (methods, locators that are identical).
Format:
The output should strictly match the format of the original file.
Do not add any unnecessary explanation or text.

Key Considerations:
Avoid redundancy: Make sure no duplicate locators or methods are added.
Correct formatting: Preserve the format (indentation, code style) of the original file.
Minimal explanation: The system should only perform the required updates without generating unnecessary
comments or explanations.


old_file_content is \n{old_file_content}\n
New Content:\n{new_file_content}

Note:- Generate only code. Don't generate any markdown codefences like ```json ```javascript etc. Only code.
No code markers.
Optimize the code such that it adheres to the Javascript and Playwright standards.

""")


def generate_pages_and_step_definition(requirement_file_content: str, feature_file_content: str) -> AutomationFiles:
    """
    Uses the given requirement text and feature file and generates Page Object classes and Step Definition file.

    :param feature_file_content: the feature(Gherkins) file text used to generate Page Objects and Step definition file.
    :param requirement_file_content: the requirement text passed in to generate Page Objects and Step definition file.

    :return: the json with Page Objects and Step Definition details.

    """
    try:
        print(f"requirements text inside generate_pages_and_step_definition \n {requirement_file_content}.\n")
        print(f"feature text inside generate_pages_and_step_definition \n {feature_file_content}.\n")

        parser = PydanticOutputParser(pydantic_object=AutomationFiles)
        intermediate_chain = PAGE_OBJECTS_AND_STEP_FILE_TEMPLATE | llm

        raw_output = intermediate_chain.invoke({
            "requirement_file_content": requirement_file_content,
            "feature_file_content": feature_file_content
        })

        # Extract content safely if wrapped in an object
        content = getattr(raw_output, "content", raw_output)
        clean_json = extract_and_sanitize_json(content)
        parsed_dict = json.loads(clean_json)

        # Now parse the cleaned JSON with your Pydantic class
        parsed = parser.pydantic_object(**parsed_dict)
        return parsed
    except Exception as e:
        print(f"Failed to generates Page Object classes and Step Definition file with requirement file "
              f"{requirement_file_content} and {feature_file_content}")
        print(e)


def extract_and_sanitize_json(text: str) -> str:
    text = text.strip()

    # Remove Markdown code blocks
    if text.startswith("```json"):
        text = text.removeprefix("```json").strip()
    elif text.startswith("```"):
        text = text.removeprefix("```").strip()
    if text.endswith("```"):
        text = text.removesuffix("```").strip()

    # Extract JSON block
    match = re.search(r'({.*})', text, re.DOTALL)
    if not match:
        raise ValueError("No valid JSON block found")

    json_str = match.group(1)

    # Fix invalid backslashes that aren't part of escape sequences
    # (e.g., \r, \n, \", etc. are valid, but \a, \l, \R are not)
    def escape_invalid_backslashes(s):
        return re.sub(r'(?<!\\)\\(?![\"\\/bfnrtu])', r'\\\\', s)

    return escape_invalid_backslashes(json_str)


def generate_feature_file_content(requirement_text: str) -> str:
    """
    Converts the given requirement text into a .feature file following the playwright-bdd format.
    The generated feature content is saved as a file in the appropriate destination.

    :param requirement_text: the requirement text passed in to generate feature file.
    :return: the content of the feature file created.
    """

    print(f"Requirement text passed in is:- {requirement_text}.")
    parser = PydanticOutputParser(pydantic_object=FeatureClass)
    chain = FEATURE_TEMPLATE | llm | parser

    response = chain.invoke({"requirement_text": requirement_text})
    return response.feature_content


def compare_and_generate_updated_content(old_file_content: str, new_file_content: str) -> str:
    """
    Compares old and new content and generates the updated content using the LLM.
    """
    chain = PAGE_OBJECT_COMPARE_AND_MERGE_PROMPT | llm | StrOutputParser()

    # Invoke the intermediate_chain to process the comparison and generate the updated content
    response = chain.invoke({
        "old_file_content": old_file_content,
        "new_file_content": new_file_content,
    })

    print(f"This is the merger response : {response}")
    # Assuming the output is returned in a format that directly gives the updated content
    return remove_markdown_fences(response)
