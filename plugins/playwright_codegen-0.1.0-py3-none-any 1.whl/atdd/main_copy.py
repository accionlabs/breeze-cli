import os
from pathlib import Path

from agents.code_generator_copy import generate_playwright_artifacts
from agents.setup_environment_copy import setup_project_environment
from utils.code_utils import remove_markdown_fences
from utils.file_util import write_file


def setup_environment():
    agent = setup_project_environment()
    response = agent.invoke({"input": "Create a Playwright blank project"})
    print(response)


def generate_playwright_code():
    requirements_path = os.getenv("REQUIREMENTS_PATH")
    req_root = Path(requirements_path).resolve()
    txt_files = list(req_root.glob("*.txt")) + list(req_root.glob("*/*.txt"))

    for req_file in txt_files:
        agent = generate_playwright_artifacts()
        req_file = req_root / req_file
        folder_name = req_file.parent.name
        feature_file_path = (Path(os.getenv("TARGET_FOLDER")).resolve() / "tests/features"
                             / folder_name / (req_file.stem + ".feature"))

        with open(req_file) as f:
            requirements_text = f.read()

        feature_result = agent.invoke(
            {"input": f"""Generate generate feature file content based on the following requirement text:
            \n{requirements_text}"""})
        write_file(feature_file_path, remove_markdown_fences(feature_result.get("output")))

        step_file_path = (Path(os.getenv("TARGET_FOLDER")).resolve() / "tests/steps"
                          / folder_name
                          / (req_file.stem + "_step.js"))
        pom_folder = (Path(os.getenv("TARGET_FOLDER")).resolve() / "tests/pages" / folder_name)

        with open(feature_file_path) as f:
            feature_text = f.read()

        result = agent.invoke(
            {"input": f"""Generate generate pages and step files based on the following:- \n
                          requirement text:\n{requirements_text}
                          feature text: \n {feature_text}"""})

        print(f"eventual result = {result}")

        write_file(step_file_path, result["output"]["step_definition"]["content"])

        for po in result["output"]["page_objects"]:
            write_file(pom_folder / po["name"], po["content"])

        print("\nPage Objects created:\n")


# setup_environment()
generate_playwright_code()
