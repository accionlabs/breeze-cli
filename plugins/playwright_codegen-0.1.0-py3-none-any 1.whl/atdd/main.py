from pathlib import Path
from atdd.utils.commandline_util import run_command

from atdd.agents.setup_environment import setup_environment_for_atdd
from atdd.utils.file_util import (
    deleteFeatureAndStepFiles,
    print_file_list,
    generate_playwright_code
)
from atdd.utils.git_utils import PLAYWRIGHT_REPO_CLONE_PATH, track_requirement_docx, push_playwright_repo

def main():
    # Path to the cloned Playwright automation repo
    target_playwright_project_root = Path(PLAYWRIGHT_REPO_CLONE_PATH)

    # Step 1: Get the list of new/updated and deleted DOCX files
    docx_files, deleted_docx_files = track_requirement_docx()

    # Step 2: Log the tracked files
    print_file_list("📄 Added/Modified DOCX files", docx_files, "➕")
    print_file_list("🗑️ Deleted DOCX files", deleted_docx_files, "❌")

    # Step 3: Delete corresponding feature and step files for deleted DOCX inputs
    deleteFeatureAndStepFiles(deleted_docx_files, target_playwright_project_root)

    # Step 4: Set up Playwright project environment if needed (e.g., folders, configs)
    setup_environment_for_atdd()

    # # Step 5: Generate feature files, step definitions, POMs, and fixtures from DOCX
    generate_playwright_code(docx_files, target_playwright_project_root)

    run_command("npm install", target_playwright_project_root)

    # push_playwright_repo()